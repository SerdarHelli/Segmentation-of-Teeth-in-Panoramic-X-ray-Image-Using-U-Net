116,113,52,17,5 ,1.png have no masks from dataset

So you must look excel to order to masks and images